setInterval(function () {
  console.log('Logging at ' + Date.now());
}, 100);